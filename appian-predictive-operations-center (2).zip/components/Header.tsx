
import React from 'react';

interface HeaderProps {
  horizon: number;
  setHorizon: (h: number) => void;
  onExport: () => void;
  autoRefresh: boolean;
  toggleAutoRefresh: () => void;
}

export const Header: React.FC<HeaderProps> = ({ horizon, setHorizon, onExport, autoRefresh, toggleAutoRefresh }) => {
  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-8 z-10 shrink-0">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-green-500 animate-pulse' : 'bg-slate-300'}`}></div>
          <span className="text-sm font-medium text-slate-600 uppercase tracking-wider">
            {autoRefresh ? 'Live Streaming' : 'System Paused'}
          </span>
        </div>
        
        <div className="flex items-center gap-2 bg-slate-50 border border-slate-200 px-3 py-1 rounded-full">
           <span className="text-[10px] font-bold text-slate-400 uppercase">Auto Refresh</span>
           <button 
             onClick={toggleAutoRefresh}
             className={`w-8 h-4 rounded-full transition-colors relative ${autoRefresh ? 'bg-blue-600' : 'bg-slate-300'}`}
           >
             <div className={`absolute top-0.5 w-3 h-3 bg-white rounded-full transition-transform ${autoRefresh ? 'translate-x-4.5' : 'translate-x-0.5'}`}></div>
           </button>
        </div>

        <div className="h-4 w-[1px] bg-slate-200"></div>
        <span className="text-sm text-slate-400 italic">
          Last Refresh: {new Date().toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
        </span>
      </div>

      <div className="flex items-center gap-6">
        <div className="flex items-center bg-slate-100 rounded-lg p-1">
          {[4, 8, 12, 24].map((h) => (
            <button
              key={h}
              onClick={() => setHorizon(h)}
              className={`px-3 py-1 text-xs font-semibold rounded-md transition-all ${
                horizon === h ? 'bg-white shadow-sm text-blue-600' : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {h}h Forecast
            </button>
          ))}
        </div>
        <button 
          onClick={() => {
            console.log("Exporting report...");
            onExport();
          }}
          className="bg-slate-900 text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-slate-800 transition-colors cursor-pointer"
        >
          Export Report
        </button>
      </div>
    </header>
  );
};
