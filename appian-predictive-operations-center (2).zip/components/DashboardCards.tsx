
import React from 'react';
import { ProcessState, SimulationResult } from '../types';

interface DashboardCardsProps {
  state: ProcessState;
  forecast: SimulationResult[];
}

export const DashboardCards: React.FC<DashboardCardsProps> = ({ state, forecast }) => {
  const latest = forecast[forecast.length - 1];
  const riskPercent = Math.round(latest.slaBreachRisk * 100);
  // Fix: Explicitly cast to number[] to avoid 'unknown' inference which causes operator '+' error in reduce
  const totalWip = (Object.values(state.wip) as number[]).reduce((a, b) => a + b, 0);
  
  const cards = [
    { title: 'Current WIP', value: totalWip, sub: 'Across all stages', trend: '+12%', trendDir: 'up', color: 'blue' },
    { title: 'SLA Health', value: '94.2%', sub: 'Target: 95%', trend: '-0.8%', trendDir: 'down', color: 'green' },
    { title: 'Predicted Breach Risk', value: `${riskPercent}%`, sub: 'Within horizon', trend: riskPercent > 50 ? 'Critical' : 'Safe', trendDir: 'up', color: riskPercent > 50 ? 'red' : 'amber' },
    { title: 'Arrival Rate', value: `${state.arrivalRate}/h`, sub: 'Normalized avg', trend: 'Stable', trendDir: 'neutral', color: 'slate' }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {cards.map((card, i) => (
        <div key={i} className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
          <p className="text-sm font-semibold text-slate-500 mb-1">{card.title}</p>
          <div className="flex items-end justify-between">
            <h3 className="text-3xl font-bold text-slate-900 tracking-tight">{card.value}</h3>
            <span className={`text-xs font-bold px-2 py-1 rounded-full ${
              card.trendDir === 'up' ? 'bg-red-50 text-red-600' : 
              card.trendDir === 'down' ? 'bg-green-50 text-green-600' : 
              'bg-slate-50 text-slate-600'
            }`}>
              {card.trend}
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-2">{card.sub}</p>
        </div>
      ))}
    </div>
  );
};
