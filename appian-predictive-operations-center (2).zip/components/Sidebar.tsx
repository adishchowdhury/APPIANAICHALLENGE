
import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const NAV_ITEMS = [
  { id: 'overview', label: 'Overview', icon: '📊' },
  { id: 'forecast', label: 'Predictive Forecast', icon: '🔮' },
  { id: 'simulator', label: 'Scenario Simulator', icon: '🧪' },
  { id: 'bottleneck', label: 'Bottleneck Map', icon: '🔥' },
  { id: 'workforce', label: 'Workforce Planner', icon: '👥' },
];

export const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <aside className="w-64 bg-slate-900 text-white flex flex-col h-full border-r border-slate-800">
      <div className="p-6 flex items-center gap-3">
        <div className="w-8 h-8 bg-blue-500 rounded flex items-center justify-center font-bold">A</div>
        <h1 className="font-bold text-lg leading-tight">Predictive Ops</h1>
      </div>
      
      <nav className="flex-1 mt-4">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={() => setActiveTab(item.id)}
            className={`w-full flex items-center gap-3 px-6 py-4 transition-all ${
              activeTab === item.id 
              ? 'bg-blue-600/20 text-blue-400 border-r-4 border-blue-500' 
              : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span className="text-xl">{item.icon}</span>
            <span className="font-medium">{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-slate-800 text-xs text-slate-500 space-y-1">
        <p>© 2024 Appian Corp</p>
        <p>Enterprise Simulation Engine v4.2</p>
        <p className="pt-2 font-medium text-slate-400 uppercase tracking-tighter">CREATED WITH <span className="text-red-500">&lt;3</span> BY ADRIJA CHOWDHURY</p>
      </div>
    </aside>
  );
};
