
export enum StageType {
  INTAKE = 'Intake',
  REVIEW = 'Review',
  APPROVAL = 'Approval'
}

export enum Complexity {
  SIMPLE = 'Simple',
  MEDIUM = 'Medium',
  COMPLEX = 'Complex'
}

export interface WorkforceStage {
  role: StageType;
  staffCount: number;
  efficiency: number; // multiplier
}

export interface ProcessState {
  arrivalRate: number; // cases per hour
  wip: Record<StageType, number>;
  workforce: Record<StageType, WorkforceStage>;
  complexityDistribution: Record<Complexity, number>; // percentages summing to 1
  slaThresholds: Record<StageType, number>; // minutes
}

export interface SimulationResult {
  timestamp: number;
  wip: Record<StageType, number>;
  throughput: number;
  slaBreachRisk: number; // 0 - 1
  bottleneckSeverity: number; // 0 - 1
}

export interface ForecastSummary {
  horizonHours: number;
  dataPoints: SimulationResult[];
  criticalStage?: StageType;
  estimatedRecoveryTime?: number;
}

export interface ScenarioComparison {
  baseline: ForecastSummary;
  simulated: ForecastSummary;
}
