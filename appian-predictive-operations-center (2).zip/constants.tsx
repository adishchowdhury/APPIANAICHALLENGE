
import { StageType, Complexity, ProcessState } from './types';

export const SIMULATION_RESOLUTION_MINUTES = 15;
export const MAX_HORIZON_HOURS = 24;

export const INITIAL_PROCESS_STATE: ProcessState = {
  arrivalRate: 45,
  wip: {
    [StageType.INTAKE]: 12,
    [StageType.REVIEW]: 48,
    [StageType.APPROVAL]: 5
  },
  workforce: {
    [StageType.INTAKE]: { role: StageType.INTAKE, staffCount: 4, efficiency: 1.0 },
    [StageType.REVIEW]: { role: StageType.REVIEW, staffCount: 8, efficiency: 1.0 },
    [StageType.APPROVAL]: { role: StageType.APPROVAL, staffCount: 3, efficiency: 1.0 }
  },
  complexityDistribution: {
    [Complexity.SIMPLE]: 0.5,
    [Complexity.MEDIUM]: 0.3,
    [Complexity.COMPLEX]: 0.2
  },
  slaThresholds: {
    [StageType.INTAKE]: 30,  // 30 mins
    [StageType.REVIEW]: 120, // 2 hours
    [StageType.APPROVAL]: 60 // 1 hour
  }
};

export const BASE_SERVICE_RATES = {
  [StageType.INTAKE]: 15,  // cases per hour per staff
  [StageType.REVIEW]: 6,   // cases per hour per staff
  [StageType.APPROVAL]: 12 // cases per hour per staff
};

export const COLORS = {
  [StageType.INTAKE]: '#3b82f6',
  [StageType.REVIEW]: '#8b5cf6',
  [StageType.APPROVAL]: '#10b981',
  SAFE: '#10b981',
  RISK: '#f59e0b',
  BREACH: '#ef4444'
};
