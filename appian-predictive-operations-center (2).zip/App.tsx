import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { DashboardCards } from './components/DashboardCards';
import { SimulationEngine } from './simulationEngine';
import { INITIAL_PROCESS_STATE, COLORS, BASE_SERVICE_RATES } from './constants';
import { StageType, ProcessState, ForecastSummary } from './types';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  BarChart, Bar, Cell, ReferenceArea
} from 'recharts';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [horizon, setHorizon] = useState(8);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [refreshKey, setRefreshKey] = useState(0);
  const [processState, setProcessState] = useState<ProcessState>(INITIAL_PROCESS_STATE);

  // Auto-refresh logic: slightly varies the arrival rate to simulate real-world drift
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      setRefreshKey(prev => prev + 1);
      setProcessState(prev => ({
        ...prev,
        // Continuous small variations in arrival rate to drive simulation dynamics
        arrivalRate: Math.max(10, Math.min(200, prev.arrivalRate * (0.98 + Math.random() * 0.04)))
      }));
    }, 5000);
    return () => clearInterval(interval);
  }, [autoRefresh]);

  // Flattened and enriched forecast data for charts
  const forecast: ForecastSummary = useMemo(() => {
    const rawForecast = SimulationEngine.runMonteCarlo(processState, horizon);
    const enrichedPoints = rawForecast.dataPoints.map(dp => ({
      ...dp,
      intakeWip: dp.wip[StageType.INTAKE],
      reviewWip: dp.wip[StageType.REVIEW],
      approvalWip: dp.wip[StageType.APPROVAL],
      riskPercent: dp.slaBreachRisk * 100,
      timeLabel: new Date(dp.timestamp).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })
    }));
    return { ...rawForecast, dataPoints: enrichedPoints as any[] };
  }, [processState, horizon, refreshKey]);

  const updateWorkforce = useCallback((stage: StageType, count: number) => {
    setProcessState(prev => ({
      ...prev,
      workforce: {
        ...prev.workforce,
        [stage]: { ...prev.workforce[stage], staffCount: Math.max(0, count) }
      }
    }));
  }, []);

  const updateEfficiency = useCallback((stage: StageType, eff: number) => {
    setProcessState(prev => ({
      ...prev,
      workforce: {
        ...prev.workforce,
        [stage]: { ...prev.workforce[stage], efficiency: Math.max(0.1, Math.min(2.0, eff)) }
      }
    }));
  }, []);

  const exportForecast = () => {
    const headers = ['Timestamp', 'Intake WIP', 'Review WIP', 'Approval WIP', 'Throughput', 'SLA Risk %'];
    const rows = forecast.dataPoints.map(dp => [
      `"${new Date(dp.timestamp).toLocaleString()}"`,
      dp.wip[StageType.INTAKE],
      dp.wip[StageType.REVIEW],
      dp.wip[StageType.APPROVAL],
      dp.throughput.toFixed(2),
      (dp.slaBreachRisk * 100).toFixed(0)
    ]);

    const csvContent = [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `predictive_ops_report_${new Date().getTime()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden">
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      
      <main className="flex-1 flex flex-col bg-slate-50 overflow-hidden">
        <Header 
          horizon={horizon} 
          setHorizon={setHorizon} 
          onExport={exportForecast} 
          autoRefresh={autoRefresh}
          toggleAutoRefresh={() => setAutoRefresh(!autoRefresh)}
        />

        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-7xl mx-auto space-y-8 pb-12">
            
            <div className="flex justify-between items-end">
              <div>
                <h1 className="text-2xl font-bold text-slate-900">
                  {activeTab === 'overview' ? 'Operational Overview' : 
                   activeTab === 'forecast' ? 'Predictive Forecast Timeline' : 
                   activeTab === 'simulator' ? 'Scenario Laboratory' : 
                   activeTab === 'workforce' ? 'Workforce Planner' : 'Process Bottleneck Map'}
                </h1>
                <p className="text-slate-500">Real-time predictive analytics and workforce optimization engine.</p>
              </div>
              <div className="text-right">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest block">System Status</span>
                <span className="text-green-600 font-bold flex items-center gap-1 justify-end">
                  <span className={`w-2 h-2 rounded-full ${autoRefresh ? 'bg-green-500 animate-pulse' : 'bg-slate-400'}`}></span>
                  {autoRefresh ? 'SYNCHRONIZED' : 'LOCAL CACHE'}
                </span>
              </div>
            </div>

            {activeTab === 'overview' && (
              <>
                <DashboardCards state={processState} forecast={forecast.dataPoints} />
                
                <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h3 className="font-bold text-slate-800">WIP Forecast Curve</h3>
                      <p className="text-xs text-slate-400">Monte Carlo Simulation - P50 Confidence Interval</p>
                    </div>
                    <div className="flex gap-4 text-xs">
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                         <span className="font-medium text-slate-600">Intake</span>
                       </div>
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 bg-purple-500 rounded-full"></div>
                         <span className="font-medium text-slate-600">Review</span>
                       </div>
                       <div className="flex items-center gap-2">
                         <div className="w-3 h-3 bg-emerald-500 rounded-full"></div>
                         <span className="font-medium text-slate-600">Approval</span>
                       </div>
                    </div>
                  </div>
                  <div className="h-[400px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={forecast.dataPoints}>
                        <defs>
                          <linearGradient id="colorIntake" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={COLORS[StageType.INTAKE]} stopOpacity={0.1}/>
                            <stop offset="95%" stopColor={COLORS[StageType.INTAKE]} stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorReview" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={COLORS[StageType.REVIEW]} stopOpacity={0.1}/>
                            <stop offset="95%" stopColor={COLORS[StageType.REVIEW]} stopOpacity={0}/>
                          </linearGradient>
                          <linearGradient id="colorApproval" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={COLORS[StageType.APPROVAL]} stopOpacity={0.1}/>
                            <stop offset="95%" stopColor={COLORS[StageType.APPROVAL]} stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="timestamp" 
                          type="number" 
                          domain={['auto', 'auto']} 
                          tickFormatter={(unix) => new Date(unix).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                          stroke="#94a3b8"
                          fontSize={11}
                        />
                        <YAxis stroke="#94a3b8" fontSize={11} />
                        <Tooltip 
                          labelFormatter={(label) => new Date(label).toLocaleTimeString()}
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)' }}
                        />
                        <Area type="monotone" dataKey="intakeWip" name="Intake" stroke={COLORS[StageType.INTAKE]} fillOpacity={1} fill="url(#colorIntake)" strokeWidth={2} />
                        <Area type="monotone" dataKey="reviewWip" name="Review" stroke={COLORS[StageType.REVIEW]} fillOpacity={1} fill="url(#colorReview)" strokeWidth={2} />
                        <Area type="monotone" dataKey="approvalWip" name="Approval" stroke={COLORS[StageType.APPROVAL]} fillOpacity={1} fill="url(#colorApproval)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </>
            )}

            {activeTab === 'forecast' && (
              <div className="space-y-8">
                <div className="bg-white p-8 rounded-xl border border-slate-200 shadow-sm">
                  <div className="flex justify-between items-start mb-8">
                    <div>
                      <h3 className="text-lg font-bold text-slate-800">SLA Breach Risk Timeline</h3>
                      <p className="text-sm text-slate-500">Visualization of process health over the next {horizon} hours.</p>
                    </div>
                    <div className="flex gap-4">
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-red-100 border border-red-500 rounded"></div>
                        <span className="text-xs text-slate-600">High Risk (&gt;70%)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-amber-100 border border-amber-500 rounded"></div>
                        <span className="text-xs text-slate-600">Elevated (30-70%)</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="w-3 h-3 bg-green-100 border border-green-500 rounded"></div>
                        <span className="text-xs text-slate-600">Safe (&lt;30%)</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="h-[500px] w-full">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={forecast.dataPoints}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                        <XAxis 
                          dataKey="timestamp" 
                          type="number" 
                          domain={['auto', 'auto']} 
                          tickFormatter={(unix) => new Date(unix).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                          stroke="#94a3b8"
                          fontSize={11}
                        />
                        <YAxis stroke="#94a3b8" fontSize={11} domain={[0, 100]} />
                        <Tooltip 
                          labelFormatter={(label) => new Date(label).toLocaleString()}
                          formatter={(val) => [`${Number(val).toFixed(1)}%`, 'Breach Risk']}
                        />
                        
                        <ReferenceArea y1={70} y2={100} fill="#fee2e2" fillOpacity={0.3} />
                        <ReferenceArea y1={30} y2={70} fill="#fef3c7" fillOpacity={0.3} />
                        <ReferenceArea y1={0} y2={30} fill="#dcfce7" fillOpacity={0.3} />

                        <Area 
                          type="monotone" 
                          dataKey="riskPercent" 
                          stroke="#ef4444" 
                          strokeWidth={3} 
                          fill="#ef4444" 
                          fillOpacity={0.1}
                          name="Breach Probability"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'workforce' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {Object.values(StageType).map(stage => {
                  const wf = processState.workforce[stage];
                  const baseRate = BASE_SERVICE_RATES[stage];
                  const capacity = wf.staffCount * baseRate * wf.efficiency;
                  const demand = processState.arrivalRate; 
                  const utilization = Math.min(100, (demand / (capacity || 1)) * 100);
                  
                  return (
                    <div key={stage} className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
                      <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                        <div className="flex items-center gap-3">
                           <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 shadow-sm flex items-center justify-center text-xl">
                              {stage === StageType.INTAKE ? '📨' : stage === StageType.REVIEW ? '🔍' : '✅'}
                           </div>
                           <h3 className="font-bold text-slate-800">{stage} Team</h3>
                        </div>
                        <div className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-widest ${utilization > 90 ? 'bg-red-100 text-red-600' : utilization > 70 ? 'bg-amber-100 text-amber-600' : 'bg-green-100 text-green-600'}`}>
                          {utilization > 90 ? 'CRITICAL' : utilization > 70 ? 'AT CAPACITY' : 'STABLE'}
                        </div>
                      </div>

                      <div className="p-8 space-y-8 flex-1">
                         <div className="grid grid-cols-2 gap-4">
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">Total Capacity</p>
                               <p className="text-xl font-black text-slate-800">{Math.round(capacity)}/h</p>
                            </div>
                            <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                               <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wide mb-1">Utilization</p>
                               <p className="text-xl font-black text-slate-800">{Math.round(utilization)}%</p>
                            </div>
                         </div>

                         <div className="space-y-6">
                            <div className="space-y-3">
                              <div className="flex justify-between text-xs font-bold text-slate-500 uppercase">
                                 <span>Headcount</span>
                                 <span className="text-blue-600">{wf.staffCount} FTE</span>
                              </div>
                              <div className="flex items-center gap-4">
                                <button onClick={() => updateWorkforce(stage, wf.staffCount - 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 active:bg-slate-100 cursor-pointer">-</button>
                                <div className="flex-1 h-2 bg-slate-100 rounded-full relative overflow-hidden">
                                   <div className="h-full bg-blue-500" style={{ width: `${(wf.staffCount / 20) * 100}%` }}></div>
                                </div>
                                <button onClick={() => updateWorkforce(stage, wf.staffCount + 1)} className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center hover:bg-slate-50 active:bg-slate-100 cursor-pointer">+</button>
                              </div>
                            </div>

                            <div className="space-y-3">
                              <div className="flex justify-between text-xs font-bold text-slate-500 uppercase">
                                 <span>Efficiency Multiplier</span>
                                 <span className="text-blue-600">{wf.efficiency.toFixed(2)}x</span>
                              </div>
                              <input 
                                type="range" 
                                min="0.5" 
                                max="2.0" 
                                step="0.1" 
                                value={wf.efficiency}
                                onChange={(e) => updateEfficiency(stage, parseFloat(e.target.value))}
                                className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                              />
                            </div>
                         </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {activeTab === 'simulator' && (
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div className="lg:col-span-1 space-y-6">
                  <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-8">
                    <h3 className="font-bold text-slate-800 border-b pb-4">Simulation Parameters</h3>
                    
                    {Object.values(StageType).map(stage => (
                      <div key={stage} className="space-y-3">
                        <div className="flex justify-between items-center">
                          <label className="text-xs font-bold text-slate-500 uppercase">{stage} Staff</label>
                          <span className="text-sm font-bold text-blue-600">{processState.workforce[stage].staffCount}</span>
                        </div>
                        <input 
                          type="range" 
                          min="1" 
                          max="20" 
                          value={processState.workforce[stage].staffCount}
                          onChange={(e) => updateWorkforce(stage, parseInt(e.target.value))}
                          className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                        />
                      </div>
                    ))}

                    <div className="pt-4 border-t">
                      <div className="flex justify-between items-center mb-3">
                        <label className="text-xs font-bold text-slate-500 uppercase">Arrival surge/h</label>
                        <span className="text-sm font-bold text-blue-600">{Math.round(processState.arrivalRate)}</span>
                      </div>
                      <input 
                        type="range" 
                        min="10" 
                        max="200" 
                        value={processState.arrivalRate}
                        onChange={(e) => setProcessState(prev => ({ ...prev, arrivalRate: parseInt(e.target.value) }))}
                        className="w-full h-2 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-blue-600"
                      />
                    </div>
                  </div>
                </div>

                <div className="lg:col-span-3 space-y-8">
                  <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm h-full flex flex-col">
                     <h3 className="font-bold text-slate-800 mb-6">Outcome Distribution</h3>
                     <div className="flex-1 h-96 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart data={forecast.dataPoints.filter((_, i) => i % 4 === 0)}>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                            <XAxis 
                              dataKey="timestamp" 
                              tickFormatter={(unix) => new Date(unix).toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' })}
                              stroke="#94a3b8"
                              fontSize={11}
                            />
                            <YAxis stroke="#94a3b8" fontSize={11} />
                            <Tooltip labelFormatter={(label) => new Date(label).toLocaleTimeString()}/>
                            <Bar dataKey="reviewWip" name="Review Backlog (Simulated)">
                              {forecast.dataPoints.filter((_, i) => i % 4 === 0).map((entry, index) => (
                                <Cell 
                                  key={`cell-${index}`} 
                                  fill={entry.slaBreachRisk > 0.6 ? COLORS.BREACH : entry.slaBreachRisk > 0.3 ? COLORS.RISK : COLORS[StageType.REVIEW]} 
                                />
                              ))}
                            </Bar>
                          </BarChart>
                        </ResponsiveContainer>
                     </div>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'bottleneck' && (
              <div className="bg-white p-12 rounded-xl border border-slate-200 shadow-sm flex flex-col items-center shrink-0">
                 <div className="flex items-center gap-12 w-full max-w-4xl relative">
                    {Object.values(StageType).map((stage, i) => {
                      const wip = processState.wip[stage];
                      const severity = Math.min(wip / 40, 1);
                      return (
                        <React.Fragment key={stage}>
                          <div className={`relative flex-1 p-8 rounded-2xl border-2 transition-all duration-700 flex flex-col items-center text-center ${
                            severity > 0.8 ? 'border-red-500 bg-red-50 shadow-[0_0_20px_rgba(239,68,68,0.2)]' : 
                            severity > 0.4 ? 'border-amber-500 bg-amber-50' : 
                            'border-green-500 bg-green-50'
                          }`}>
                            {severity > 0.8 && <div className="absolute -top-3 -right-3 bg-red-500 text-white text-[10px] px-2 py-1 rounded-full animate-bounce font-bold">BOTTLENECK</div>}
                            <span className="text-2xl mb-2">{i === 0 ? '📨' : i === 1 ? '🔍' : '✅'}</span>
                            <h4 className="font-bold text-slate-900">{stage}</h4>
                            <p className="text-2xl font-black mt-2">{Math.round(wip)}</p>
                            <p className="text-[10px] text-slate-400 uppercase tracking-widest mt-1">Items WIP</p>
                          </div>
                          {i < 2 && (
                            <div className="w-12 h-1 bg-slate-200 relative overflow-hidden">
                              <div className="absolute inset-0 bg-blue-500 animate-slide-right"></div>
                            </div>
                          )}
                        </React.Fragment>
                      )
                    })}
                 </div>
              </div>
            )}
          </div>
        </div>
      </main>

      <style>{`
        @keyframes slide-right {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-slide-right {
          animation: slide-right 2s linear infinite;
        }
        input[type="range"]::-webkit-slider-thumb {
          -webkit-appearance: none;
          appearance: none;
          width: 16px;
          height: 16px;
          background: #3b82f6;
          border-radius: 50%;
          cursor: pointer;
          border: 2px solid white;
          box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
      `}</style>
    </div>
  );
};

export default App;