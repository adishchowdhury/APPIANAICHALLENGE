
import { ProcessState, SimulationResult, StageType, ForecastSummary, Complexity } from './types';
import { BASE_SERVICE_RATES, SIMULATION_RESOLUTION_MINUTES } from './constants.tsx';

/**
 * Probabilistic Simulation Engine
 * Uses a discrete-time approximation of a M/G/c queue network.
 * Each stage's output feeds the next stage's input.
 */
export class SimulationEngine {
  
  static run(state: ProcessState, horizonHours: number): ForecastSummary {
    const dataPoints: SimulationResult[] = [];
    const steps = (horizonHours * 60) / SIMULATION_RESOLUTION_MINUTES;
    
    // Copy current state for mutability during step-through
    let currentWip = { ...state.wip };
    const stages = [StageType.INTAKE, StageType.REVIEW, StageType.APPROVAL];

    for (let step = 0; step <= steps; step++) {
      const timeInHours = (step * SIMULATION_RESOLUTION_MINUTES) / 60;
      const timestamp = Date.now() + timeInHours * 3600000;

      // 1. Calculate Arrivals for this interval (Lambda)
      // We use a small random variance to simulate real-world arrival patterns
      const variance = 0.8 + Math.random() * 0.4;
      const arrivalsAtIntake = (state.arrivalRate / (60 / SIMULATION_RESOLUTION_MINUTES)) * variance;
      
      // 2. Process each stage (Service Rate Mu)
      const stageOutputs: Record<StageType, number> = {
        [StageType.INTAKE]: 0,
        [StageType.REVIEW]: 0,
        [StageType.APPROVAL]: 0
      };

      stages.forEach(stage => {
        const workforce = state.workforce[stage];
        const baseRate = BASE_SERVICE_RATES[stage];
        
        // Potential throughput if queue was full
        const capacityPerInterval = (workforce.staffCount * baseRate * workforce.efficiency) / (60 / SIMULATION_RESOLUTION_MINUTES);
        
        // Actual processed is the minimum of capacity and current WIP
        const processed = Math.min(currentWip[stage], capacityPerInterval);
        stageOutputs[stage] = processed;
      });

      // 3. Update WIP for next step (WIP_t+1 = WIP_t + Arrivals - Departures)
      // New WIP at Intake
      currentWip[StageType.INTAKE] += arrivalsAtIntake - stageOutputs[StageType.INTAKE];
      
      // New WIP at Review (Intake outputs feed Review)
      currentWip[StageType.REVIEW] += stageOutputs[StageType.INTAKE] - stageOutputs[StageType.REVIEW];
      
      // New WIP at Approval (Review outputs feed Approval)
      currentWip[StageType.APPROVAL] += stageOutputs[StageType.REVIEW] - stageOutputs[StageType.APPROVAL];

      // Ensure no negative WIP
      stages.forEach(s => { if (currentWip[s] < 0) currentWip[s] = 0; });

      // 4. Calculate Risk Levels
      // Risk is high if WIP > Capacity * Threshold_Multiplier
      const totalRisk = stages.reduce((acc, stage) => {
        const threshold = (state.workforce[stage].staffCount * BASE_SERVICE_RATES[stage] * (state.slaThresholds[stage] / 60));
        return acc + (currentWip[stage] > threshold ? 0.33 : 0);
      }, 0);

      dataPoints.push({
        timestamp,
        wip: { ...currentWip },
        throughput: Object.values(stageOutputs).reduce((a, b) => a + b, 0),
        slaBreachRisk: Math.min(totalRisk, 1),
        bottleneckSeverity: Math.max(...stages.map(s => {
           const cap = (state.workforce[s].staffCount * BASE_SERVICE_RATES[s]);
           return Math.min(currentWip[s] / (cap || 1), 1.5);
        })) / 1.5
      });
    }

    return {
      horizonHours,
      dataPoints,
      criticalStage: stages.reduce((prev, curr) => 
        currentWip[curr] > currentWip[prev] ? curr : prev
      )
    };
  }

  /**
   * Monte Carlo wrapper to get confidence intervals
   */
  static runMonteCarlo(state: ProcessState, horizonHours: number, iterations: number = 20) {
    const results = Array.from({ length: iterations }).map(() => this.run(state, horizonHours));
    
    // Aggregate results for P50, P75, P95 (simplified average for this implementation)
    const aggregated = results[0].dataPoints.map((_, i) => {
      const point: any = { ...results[0].dataPoints[i] };
      const allWips = results.map(r => r.dataPoints[i].wip);
      
      // Calculate mean WIP per stage across iterations
      Object.values(StageType).forEach(stage => {
        const values = allWips.map(w => w[stage as StageType]).sort((a, b) => a - b);
        point.wip[stage as StageType] = values[Math.floor(values.length / 2)]; // Median (P50)
        point[`wip_p95_${stage}`] = values[Math.floor(values.length * 0.95)]; // P95
      });
      
      return point;
    });

    return { ...results[0], dataPoints: aggregated };
  }
}
